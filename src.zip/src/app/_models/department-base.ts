export class DepartmentBase {
    constructor(public _id?: number, public Name?: string) { }
}
